// ============================================================
// 『ミクロ経済学（仮題）』講義スライド雛型（Typst + Touying 版）
//   コンパイル: typst compile main.typ  （Typst 0.13 以上）
//   コマ画像: beamer_kit.zip を展開し、frames/ フォルダを
//             このファイルと同じ場所に置いてください。
//
// 配布資料を作るとき:
//   下の handout を true にして再コンパイル。
//   アニメのコマ送りが「4コマ1枚」のまとめ図に自動で置き換わります。
// ============================================================
#import "@preview/touying:0.6.1": *
#import themes.simple: *
#import "book-animes.typ": anime-slide

#let handout = false // ← 配布資料は true に

#show: simple-theme.with(aspect-ratio: "16-9")
#set text(
  font: ("Helvetica Neue", "Hiragino Kaku Gothic ProN", "Noto Sans CJK JP", "Yu Gothic"),
  lang: "ja",
  size: 20pt,
)

#title-slide[
  = 講義スライド雛型
  『ミクロ経済学（仮題）』（多鹿 智哉・栗田 健一）図版利用サンプル
]

== 使い方（このスライドは配布時に削除してください）

- アニメ図版は `#anime-slide("図のid", title: [見出し], handout: handout)` の1行で1枚のスライドになります。投影ではクリックごとにコマが進みます。
- 配布資料はこのファイル冒頭の `handout` を `true` にして再コンパイル。4コマまとめ図に置き換わります。
- 図のidは Web教材の#link("https://ttajika.github.io/micro-contents/anime_gallery.html")[アニメーション一覧]で各図の「リンクをコピー」を押すと URL 末尾（`#` の後）に入っています。
- コマ画像は `beamer_kit.zip` を展開して `frames/` をこのファイルの隣に置いてください。
- 静止画図版（SVG／PDF）は#link("https://ttajika.github.io/micro-contents/image_gallery.html")[図版一覧]からダウンロードして `#image(...)` で貼れます。

// ── 例: コマ送り（投影）／4コマ1枚（handout）─────────────
#anime-slide("anime-pigou", title: [例：外部性の内部化（ピグー税）], handout: handout)

== 図版の出典表記の例

スライド配布時は、利用した図に出典を明記してください：

#quote(block: true)[
  多鹿智哉・栗田健一『ミクロ経済学（仮題）』（新世社）図X.Y.Z \
  （Web教材 https://ttajika.github.io/micro-contents/ より）
]
